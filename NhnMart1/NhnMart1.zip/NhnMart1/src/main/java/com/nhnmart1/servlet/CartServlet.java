package com.nhnmart1.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "cartServlet",urlPatterns = "/cart")
public class CartServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        String items[] = req.getParameterValues("items");
        PrintWriter out = resp.getWriter();
        out.println("<html><head></head><body>");
        if(items==null){
            out.println("선택한 물품이 없습니다.");
        }else{
            out.println("물건리스트.</br>");
            for(String item:items){
                out.println(item);
            }
        }
        out.println("<br><a href='/foods'>뒤로가기</a>");
        out.println("</body></html>");
        out.close();
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {
        doGet(req, resp);
    }



}
