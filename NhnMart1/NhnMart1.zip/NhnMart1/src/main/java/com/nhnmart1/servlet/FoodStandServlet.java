package com.nhnmart1.servlet;

import com.nhnmart1.domain.Food;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet(name = "foodStandServlet",urlPatterns = "/init")
public class FoodStandServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
        throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html");
        resp.setCharacterEncoding("UTF-8");
        ServletContext servletContext = getServletContext();
        PrintWriter out = resp.getWriter();
        int onion = Integer.parseInt(servletContext.getInitParameter("양파"));
        int egg = Integer.parseInt(servletContext.getInitParameter("계란"));
        int leek = Integer.parseInt(servletContext.getInitParameter("파"));
        int apple = Integer.parseInt(servletContext.getInitParameter("사과"));

        ArrayList<Food> foods = new ArrayList<>();
        for(int i = 0; i<2; i++){
            foods.add(new Food("양파",onion));
        }
        for(int i = 0; i<5; i++){
            foods.add(new Food("계란",egg));
        }
        for(int i = 0; i<10; i++){
            foods.add(new Food("파",leek));
        }
        for(int i = 0; i<20; i++){
            foods.add(new Food("사과",apple));
        }
//        out.println("<a href=\"/foods\">물품목록</a>");
        servletContext.setAttribute("foods",foods);
        out.println("<a href=\"/foods\">foods</a>");
//        out.println(servletContext.getAttribute("foods"));

//        RequestDispatcher rd = req.getRequestDispatcher("/foodstand.jsp");
//        rd.forward(req,resp);
//        for(int i= 0;i<foods.size();i++) {
//            out.println(foods.get(i).getName() + foods.get(i).getPrice()
//                +"<input type=\"checkbox\" name=\"buy\" value=\"buy\">"+"<br/>");
//        }
//        out.println("<form action=\"/cart\">");
//        out.println("<input type=\"submit\" value=\"장바구니\">");
//        out.println("</form>");
//
//        req.setAttribute("foods",foods); 여기까지


//        RequestDispatcher rd = req.getRequestDispatcher("/foodstand.jsp");
//        rd.forward(req,resp);
//        req.getServletContext().setAttribute("foodList",foods);
//        req.getAttribute("foods");




    }

//    @Override
//    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
//        throws ServletException, IOException {
//        doGet(req,resp);
//    }
}
